CVE-2022-32250 - nftables kernel exploit (Ubuntu 22.04 compatible)

Ce package contient un binaire statique déjà compilé, prêt à l’emploi.

Utilisation :
-------------
1. Donne les permissions d’exécution :
   chmod +x exploit32250_static

2. Lance-le :
   ./exploit32250_static

Si vulnérable, tu obtiendras un shell root (#).
